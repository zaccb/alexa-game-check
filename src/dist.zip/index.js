// Import alexa-sdk library
'use strict';
var Alexa = require('alexa-sdk');
// var APP_ID = undefined;  // TODO replace with your app ID (OPTIONAL).

exports.handler = function(event, context, callback){
    var alexa = Alexa.handler(event, context);
    // alexa.APP_ID = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};

// Intent handler
var handlers = {
  'LaunchRequest': function () {
    this.emit('GetEventIntent');
  },

  'GetEventIntent': function () {
      this.emit(':tell', "No");
  }
}
